# 🧪 NIDAN Pathology Lab Reporting System

Professional web-based Pathology Laboratory Reporting System.

## 🏥 NIDAN Pathology Lab

This project is designed for pathology laboratory report entry, management, preview and printing.

## ✨ Features

- Patient Registration
- Automatic Patient ID
- Patient Name, Age & Gender
- Referring Doctor
- Sample Date
- Blood Test Result Entry
- CBC
- LFT
- KFT
- Blood Sugar
- Lipid Profile
- Urine Examination
- Units & Reference Ranges
- High / Low Result Flags
- Report Preview
- Print-ready Laboratory Report
- Mobile Responsive Design

## 🛠 Technology

- Next.js
- React
- JavaScript
- CSS
- Vercel

## 📁 Project Structure

nidan-pathology-lab/
├── app/
│   ├── layout.js
│   ├── page.js
│   └── globals.css
├── package.json
└── README.md

## 🚀 Deployment

Designed to be deployed using Vercel.

## ⚕️ Important

Reference ranges may vary according to laboratory method, age,
sex and clinical circumstances. Laboratory values should always
be interpreted in appropriate clinical context.

---

© 2026 NIDAN Pathology Lab


## Commercial SaaS foundation (v1.1.0)

This build includes a production-oriented commercial foundation for multi-lab deployment: tenant-aware lab membership, role-aware access, lab-scoped identifiers, hardened Supabase functions, and a dedicated password recovery screen.

### Recommended production checklist
- Configure Supabase Auth redirect URLs for `/reset-password`.
- Keep Row Level Security enabled on all tenant tables.
- Move laboratory branding/assets to Supabase Storage.
- Centralize test parameters/reference ranges in database master tables.
- Add automated E2E tests before onboarding paying laboratories.
