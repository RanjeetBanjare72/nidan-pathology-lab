const fs=require('fs'), path=require('path');
const required=['app','package.json'];
for(const p of required){if(!fs.existsSync(path.join(process.cwd(),p))) throw new Error('Missing '+p);}
const reset=path.join(process.cwd(),'app','reset-password','page.js');
if(!fs.existsSync(reset)) throw new Error('Missing reset-password page');
console.log('NIDAN smoke check: PASS');
