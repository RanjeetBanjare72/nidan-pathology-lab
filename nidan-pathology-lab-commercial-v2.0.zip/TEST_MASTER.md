# NIDAN Lab Pro v1.7

Centralized Test Master:
- test code/name/category/specimen/department/price
- parameters with result type, unit and display order
- sex/age-aware reference ranges
- critical low/high values
- result validation and high/low/critical evaluation

Supabase remains the source of truth and tenant membership RLS protects lab data.
