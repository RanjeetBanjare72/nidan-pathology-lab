# QR Verification

Released reports receive a unique verification token and immutable JSON snapshot.
The QR code should point to `/verify-report/<token>`.

The public endpoint exposes only the stored released snapshot; normal tenant tables remain protected by RLS.
Production UI should render a clean patient/report verification page rather than raw JSON.
