-- NIDAN Lab Pro v1.7
-- Centralized test master, parameters and age/sex-aware reference ranges.

create table if not exists public.lab_test_master (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  code text not null,
  name text not null,
  category text,
  specimen text,
  department text,
  price numeric(12,2) not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(lab_id, code)
);

create table if not exists public.lab_test_parameters (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  test_id uuid not null references public.lab_test_master(id) on delete cascade,
  code text not null,
  name text not null,
  result_type text not null default 'numeric'
    check (result_type in ('numeric','text','positive_negative','select')),
  unit text,
  sort_order integer not null default 0,
  required boolean not null default true,
  created_at timestamptz not null default now(),
  unique(lab_id,test_id,code)
);

create table if not exists public.lab_reference_ranges (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  parameter_id uuid not null references public.lab_test_parameters(id) on delete cascade,
  sex text not null default 'all'
    check (sex in ('male','female','other','all')),
  age_min numeric,
  age_max numeric,
  low_value numeric,
  high_value numeric,
  text_range text,
  critical_low numeric,
  critical_high numeric,
  created_at timestamptz not null default now()
);

create index if not exists idx_lab_test_master_lab_active
  on public.lab_test_master(lab_id, active);
create index if not exists idx_lab_test_params_test
  on public.lab_test_parameters(lab_id, test_id, sort_order);
create index if not exists idx_lab_reference_param
  on public.lab_reference_ranges(lab_id, parameter_id);

alter table public.lab_test_master enable row level security;
alter table public.lab_test_parameters enable row level security;
alter table public.lab_reference_ranges enable row level security;

drop policy if exists "test_master tenant" on public.lab_test_master;
create policy "test_master tenant" on public.lab_test_master for all to authenticated
using (exists (
  select 1 from public.lab_members lm
  where lm.lab_id=lab_test_master.lab_id
    and lm.user_id=auth.uid()
    and lm.active
))
with check (exists (
  select 1 from public.lab_members lm
  where lm.lab_id=lab_test_master.lab_id
    and lm.user_id=auth.uid()
    and lm.active
));

drop policy if exists "test_params tenant" on public.lab_test_parameters;
create policy "test_params tenant" on public.lab_test_parameters for all to authenticated
using (exists (
  select 1 from public.lab_members lm
  where lm.lab_id=lab_test_parameters.lab_id
    and lm.user_id=auth.uid()
    and lm.active
))
with check (exists (
  select 1 from public.lab_members lm
  where lm.lab_id=lab_test_parameters.lab_id
    and lm.user_id=auth.uid()
    and lm.active
));

drop policy if exists "reference tenant" on public.lab_reference_ranges;
create policy "reference tenant" on public.lab_reference_ranges for all to authenticated
using (exists (
  select 1 from public.lab_members lm
  where lm.lab_id=lab_reference_ranges.lab_id
    and lm.user_id=auth.uid()
    and lm.active
))
with check (exists (
  select 1 from public.lab_members lm
  where lm.lab_id=lab_reference_ranges.lab_id
    and lm.user_id=auth.uid()
    and lm.active
));
