-- NIDAN Lab Pro v1.6: immutable released report snapshot + public verification token
create table if not exists public.report_release_snapshots (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  report_id uuid not null,
  verification_token text not null unique,
  snapshot jsonb not null,
  released_by uuid references auth.users(id) on delete set null,
  released_at timestamptz not null default now()
);

create unique index if not exists uq_report_release_once
  on public.report_release_snapshots(report_id);

create index if not exists idx_report_verify_token
  on public.report_release_snapshots(verification_token);

alter table public.report_release_snapshots enable row level security;

drop policy if exists "tenant snapshots select" on public.report_release_snapshots;
create policy "tenant snapshots select"
on public.report_release_snapshots for select to authenticated
using (exists (
  select 1 from public.lab_members lm
  where lm.lab_id = report_release_snapshots.lab_id
    and lm.user_id = auth.uid()
    and lm.active
));

-- Public verification uses a narrowly scoped SECURITY DEFINER function.
create or replace function public.verify_report(p_token text)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'verified', true,
    'report', snapshot,
    'released_at', released_at
  )
  from public.report_release_snapshots
  where verification_token = p_token
  limit 1;
$$;

revoke all on function public.verify_report(text) from public;
grant execute on function public.verify_report(text) to anon, authenticated;
