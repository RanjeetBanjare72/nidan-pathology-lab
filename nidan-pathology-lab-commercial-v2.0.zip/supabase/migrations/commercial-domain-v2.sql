-- NIDAN Lab Pro Commercial v2.0
-- Consolidated SaaS domain foundation. Run after reviewing against the existing schema.

create table if not exists public.lab_doctors (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  name text not null, qualification text, phone text, registration_no text,
  active boolean not null default true, created_at timestamptz not null default now()
);

create table if not exists public.lab_patients (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  patient_no text not null, full_name text not null, sex text,
  date_of_birth date, phone text, address text, created_at timestamptz not null default now(),
  unique(lab_id, patient_no)
);

create table if not exists public.lab_orders (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  patient_id uuid not null references public.lab_patients(id) on delete restrict,
  doctor_id uuid references public.lab_doctors(id) on delete set null,
  order_no text not null, status text not null default 'pending',
  total_amount numeric(12,2) not null default 0,
  paid_amount numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  unique(lab_id, order_no)
);

create table if not exists public.lab_order_tests (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  order_id uuid not null references public.lab_orders(id) on delete cascade,
  test_id uuid not null references public.lab_test_master(id) on delete restrict,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  unique(order_id,test_id)
);

create table if not exists public.lab_samples (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  order_id uuid not null references public.lab_orders(id) on delete cascade,
  sample_no text not null, specimen text, status text not null default 'pending',
  collected_at timestamptz, received_at timestamptz, created_at timestamptz not null default now(),
  unique(lab_id,sample_no)
);

create table if not exists public.lab_results (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  order_test_id uuid not null references public.lab_order_tests(id) on delete cascade,
  parameter_id uuid not null references public.lab_test_parameters(id) on delete restrict,
  result_value text,
  flag text,
  critical boolean not null default false,
  entered_by uuid references auth.users(id) on delete set null,
  entered_at timestamptz,
  updated_at timestamptz not null default now(),
  unique(order_test_id,parameter_id)
);

create table if not exists public.lab_invoices (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  order_id uuid not null references public.lab_orders(id) on delete cascade,
  invoice_no text not null, subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0, tax numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0, paid numeric(12,2) not null default 0,
  status text not null default 'unpaid', created_at timestamptz not null default now(),
  unique(lab_id,invoice_no)
);

create table if not exists public.lab_subscriptions (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  plan text not null default 'trial',
  status text not null default 'active',
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

-- Tenant isolation: authenticated members may only access records belonging to their lab.
do $$
declare t text;
begin
  foreach t in array array[
    'lab_doctors','lab_patients','lab_orders','lab_order_tests',
    'lab_samples','lab_results','lab_invoices','lab_subscriptions'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists tenant_access on public.%I', t);
    execute format(
      'create policy tenant_access on public.%I for all to authenticated
       using (exists (select 1 from public.lab_members lm where lm.lab_id=%I.lab_id and lm.user_id=auth.uid() and lm.active))
       with check (exists (select 1 from public.lab_members lm where lm.lab_id=%I.lab_id and lm.user_id=auth.uid() and lm.active))',
      t,t,t
    );
  end loop;
end $$;
