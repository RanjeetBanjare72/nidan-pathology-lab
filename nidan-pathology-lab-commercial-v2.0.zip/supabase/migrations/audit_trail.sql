-- NIDAN Lab Pro: immutable audit trail foundation
create table if not exists public.lab_audit_logs (
  id uuid primary key default gen_random_uuid(),
  lab_id uuid not null references public.labs(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  metadata jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_lab_audit_lab_created on public.lab_audit_logs(lab_id, created_at desc);
create index if not exists idx_lab_audit_entity on public.lab_audit_logs(entity_type, entity_id);

alter table public.lab_audit_logs enable row level security;
drop policy if exists "tenant lab_audit_logs select" on public.lab_audit_logs;
create policy "tenant lab_audit_logs select"
on public.lab_audit_logs for select to authenticated
using (exists (
  select 1 from public.lab_members lm
  where lm.lab_id = lab_audit_logs.lab_id
    and lm.user_id = auth.uid()
    and lm.active
));
drop policy if exists "tenant lab_audit_logs insert" on public.lab_audit_logs;
create policy "tenant lab_audit_logs insert"
on public.lab_audit_logs for insert to authenticated
with check (exists (
  select 1 from public.lab_members lm
  where lm.lab_id = lab_audit_logs.lab_id
    and lm.user_id = auth.uid()
    and lm.active
));

-- Do not expose update/delete policies: audit records are append-only.
