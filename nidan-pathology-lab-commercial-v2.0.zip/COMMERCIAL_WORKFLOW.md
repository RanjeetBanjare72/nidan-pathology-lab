# NIDAN Lab Pro — Commercial Workflow

## Canonical workflow
Patient → Order → Sample → Result Entry → Pathologist Verification → Report Release → QR/Print/PDF

## Tenant rule
Every clinical/business record must carry `lab_id`. Browser localStorage is UI cache only; Supabase is the source of truth.

## Roles
- owner: subscription, lab settings, staff, all clinical/business actions
- admin: operational management and staff
- receptionist: patients, orders, billing
- technician: samples and result entry
- pathologist: result verification/release
- billing: billing/invoices

## Release rule
A report must not become `released/completed` until the required verification step is complete.

## Commercial readiness checklist
- RLS/tenant isolation
- centralized test + parameter + reference range master
- audit trail for result edits/release
- immutable released report snapshot
- report QR verification endpoint
- subscription entitlement checks
- automated smoke tests
