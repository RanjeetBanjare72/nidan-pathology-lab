'use client';

import { useState } from 'react';
import { REPORT_STATUS } from '../lib/lab-workflow';

export default function ReportReleasePanel({ report, user, onVerify, onRelease }) {
  const [busy, setBusy] = useState(false);
  const isClinical = ['owner','admin','pathologist'].includes(user?.role);
  const verifyable = report?.status === REPORT_STATUS.PENDING_VERIFICATION;
  const releasable = report?.status === REPORT_STATUS.VERIFIED;

  async function run(action) {
    setBusy(true);
    try { await action(); } finally { setBusy(false); }
  }

  return (
    <section className="nidan-card" style={{padding:18}}>
      <div style={{display:'flex',justifyContent:'space-between',gap:16,alignItems:'center'}}>
        <div>
          <strong>Report verification</strong>
          <div className="nidan-muted" style={{marginTop:4}}>
            Status: {report?.status || 'draft'}
          </div>
        </div>
        <span className={`nidan-status ${
          releasable ? 'nidan-status--success' :
          verifyable ? 'nidan-status--warning' : 'nidan-status--info'
        }`}>
          {report?.status || 'draft'}
        </span>
      </div>
      {isClinical && (
        <div style={{display:'flex',gap:10,marginTop:16}}>
          {verifyable && (
            <button disabled={busy} onClick={() => run(onVerify)}>
              {busy ? 'Saving…' : 'Verify results'}
            </button>
          )}
          {releasable && (
            <button disabled={busy} onClick={() => run(onRelease)}>
              {busy ? 'Releasing…' : 'Release report'}
            </button>
          )}
        </div>
      )}
    </section>
  );
}
