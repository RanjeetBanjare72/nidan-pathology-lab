'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

export default function ReportVerificationCard({ token }) {
  const [state, setState] = useState({loading:true, data:null, error:null});
  useEffect(() => {
    let active = true;
    (async () => {
      const { data, error } = await supabase.rpc('verify_report', { p_token: token });
      if (!active) return;
      if (error || !data?.verified) setState({loading:false,data:null,error:'Report could not be verified'});
      else setState({loading:false,data,error:null});
    })();
    return () => { active = false; };
  }, [token]);
  if (state.loading) return <div className="nidan-card" style={{padding:24}}>Verifying report…</div>;
  if (state.error) return <div className="nidan-card" style={{padding:24}}><strong>Verification failed</strong><p className="nidan-muted">{state.error}</p></div>;
  return (
    <div className="nidan-card" style={{padding:24}}>
      <div className="nidan-status nidan-status--success">✓ Verified report</div>
      <h2 style={{marginTop:14}}>NIDAN Laboratory Report</h2>
      <p className="nidan-muted">Released: {new Date(state.data.released_at).toLocaleString()}</p>
      <pre style={{whiteSpace:'pre-wrap',overflowWrap:'anywhere'}}>{JSON.stringify(state.data.report,null,2)}</pre>
    </div>
  );
}
