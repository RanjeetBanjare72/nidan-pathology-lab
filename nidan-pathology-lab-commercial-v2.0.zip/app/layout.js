import "./globals.css";

export const metadata = {
  title: "NIDAN Lab Pro | Pathology Laboratory Management",
  description:
    "NIDAN Lab Pro - Professional multi-lab pathology laboratory management and reporting software",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
