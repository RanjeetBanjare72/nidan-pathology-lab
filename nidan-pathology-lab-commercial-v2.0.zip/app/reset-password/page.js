"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { supabase } from "../../lib/supabase";

export default function ResetPasswordPage() {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (!active) return;
      if (event === "PASSWORD_RECOVERY") setReady(true);
      if (session) setReady(true);
    });

    supabase.auth.getSession().then(({ data: sessionData }) => {
      if (active && sessionData?.session) setReady(true);
    });

    return () => {
      active = false;
      data.subscription.unsubscribe();
    };
  }, []);

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setMessage("");

    if (password.length < 8) {
      setError("Password कम से कम 8 characters का होना चाहिए।");
      return;
    }
    if (password !== confirm) {
      setError("दोनों passwords match नहीं कर रहे हैं।");
      return;
    }

    try {
      setLoading(true);
      const { error: updateError } = await supabase.auth.updateUser({ password });
      if (updateError) throw updateError;
      setMessage("Password successfully update हो गया। अब login करें।");
      setTimeout(() => router.replace("/login"), 1200);
    } catch (err) {
      setError(err?.message || "Password update नहीं हो पाया। Reset link फिर से request करें।");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="resetPage">
      <div className="resetGlow resetGlowOne" />
      <div className="resetGlow resetGlowTwo" />
      <section className="resetCard">
        <div className="resetBrand">
          <div className="resetLogo">N+</div>
          <div>
            <div className="resetBrandName">NIDAN</div>
            <div className="resetBrandSub">PATHOLOGY LAB PRO</div>
          </div>
        </div>

        <div className="resetIcon">🔐</div>
        <h1>Set a new password</h1>
        <p className="resetIntro">अपने NIDAN Lab account के लिए नया secure password बनाइए।</p>

        {!ready && !message && (
          <div className="resetNotice">
            Reset link session नहीं मिली। Login page से नया reset link request करें।
          </div>
        )}

        {error && <div className="resetError">{error}</div>}
        {message && <div className="resetSuccess">{message}</div>}

        <form onSubmit={handleSubmit} className="resetForm">
          <label>
            New password
            <div className="passwordField">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 8 characters"
                autoComplete="new-password"
                disabled={!ready || loading}
              />
              <button type="button" onClick={() => setShowPassword((v) => !v)} disabled={loading}>
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </label>

          <label>
            Confirm password
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="Repeat your password"
              autoComplete="new-password"
              disabled={!ready || loading}
            />
          </label>

          <button className="resetSubmit" type="submit" disabled={!ready || loading}>
            {loading ? "Updating..." : "Update Password"}
          </button>
        </form>

        <Link href="/login" className="resetBack">← Back to login</Link>
      </section>
    </main>
  );
}
