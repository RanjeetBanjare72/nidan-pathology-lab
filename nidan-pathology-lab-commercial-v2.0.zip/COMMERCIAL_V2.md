# NIDAN Lab Pro Commercial v2.0

Single consolidated commercial foundation:
Patient → Doctor → Order → Payment → Sample → Result → Verification → Release → QR/PDF

Includes database foundations for:
- patients
- doctors
- orders/order tests
- samples
- results
- invoices
- subscriptions
- multi-lab RLS

Important: migration must be reviewed against the current production schema before execution. Existing tables are not dropped.
