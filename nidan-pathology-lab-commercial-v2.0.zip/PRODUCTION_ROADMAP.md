# NIDAN Lab Pro — Production Roadmap

1. Audit trail (included in v1.5)
2. Result verification/release DB enforcement
3. Immutable released report snapshot
4. QR report verification
5. Remove clinical localStorage as source of truth
6. Centralize test/parameter/reference-range master
7. Subscription entitlements + expiry
8. Super Admin tenant management
9. Automated smoke/E2E tests
10. Production deployment and security review
