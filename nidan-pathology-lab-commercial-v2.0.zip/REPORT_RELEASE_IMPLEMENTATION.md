# Report Release Implementation

UI/service helpers are included for:
- Pathologist/Admin/Owner verification
- verified_at / verified_by
- release only after verification
- released_at / released_by

Production integration should call Supabase updates through tenant-aware RLS and create an audit record for every verification/release action. Released reports should be immutable.
