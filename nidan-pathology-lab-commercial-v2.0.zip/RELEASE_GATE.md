# NIDAN Lab Pro v1.3.0 — Release Gate

Canonical workflow:
Patient → Order → Sample → Result Entry → Pathologist Verification → Report Release → QR/Print/PDF

A report must only move:
draft → pending_verification → verified → released

Released reports should be immutable. Corrections should use a controlled amended-report flow with an audit record.

Next implementation:
- server-side transition enforcement
- result verification UI
- immutable report snapshot
- QR verification
- migrate remaining clinical localStorage state to Supabase
